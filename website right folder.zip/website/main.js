 function Total(){
                let femaleQty = document.getElementById('fQuantity').value;
                let maleQty = document.getElementById('mQuantity').value;

                let fPrice = 150.95 * femaleQty;
                let mPrice = 180.95 * maleQty;

            
                console.log(fPrice)
                console.log(mPrice)

                let total = eval(fPrice + mPrice);
                console.log(total)
                document.getElementById('fTotal').value =`R${fPrice}`;
                document.getElementById('mTotal').value = `R${mPrice}`;
                document.getElementById('displayTotal').value = `R${total}`;

            }